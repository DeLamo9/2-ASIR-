from django.contrib import admin
from .models import ImpuestoSociedades

admin.site.register(ImpuestoSociedades)