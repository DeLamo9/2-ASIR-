from django.db import models

class ImpuestoSociedades(models.Model):
    nif_cliente = models.CharField(max_length=20)
    cif_empresa = models.CharField(max_length=20)
    numero_impuesto = models.CharField(max_length=10)
    provincia = models.CharField(max_length=50)
    valor_producto = models.DecimalField(max_digits=10, decimal_places=2)
    antiguedad_mayor_3 = models.BooleanField(default=False)
    datos = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    def __str__(self):
        return f"Impuesto {self.numero_impuesto} - {self.cif_empresa}"
