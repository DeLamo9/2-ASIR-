from django.urls import path
from django.shortcuts import render
from . import views

urlpatterns = [
    path('', views.formulario_impuesto, name='formulario_impuesto'),
    path('exito/', lambda r: render(r, 'exito.html'), name='formulario_exito'),
    path('error/', lambda r: render(r, 'error.html'), name='formulario_error'),
]