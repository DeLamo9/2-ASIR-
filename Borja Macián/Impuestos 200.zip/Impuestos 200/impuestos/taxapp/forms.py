from django import forms
from .models import ImpuestoSociedades

PROVINCIAS = [
    ('A Coruña', 'A Coruña'),
    ('Álava', 'Álava'),
    ('Albacete', 'Albacete'),
    ('Alicante', 'Alicante'),
    ('Almería', 'Almería'),
    ('Asturias', 'Asturias'),
    ('Ávila', 'Ávila'),
    ('Badajoz', 'Badajoz'),
    ('Barcelona', 'Barcelona'),
    ('Burgos', 'Burgos'),
    ('Cáceres', 'Cáceres'),
    ('Cádiz', 'Cádiz'),
    ('Cantabria', 'Cantabria'),
    ('Castellón', 'Castellón'),
    ('Ciudad Real', 'Ciudad Real'),
    ('Córdoba', 'Córdoba'),
    ('Cuenca', 'Cuenca'),
    ('Girona', 'Girona'),
    ('Granada', 'Granada'),
    ('Guadalajara', 'Guadalajara'),
    ('Guipúzcoa', 'Guipúzcoa'),
    ('Huelva', 'Huelva'),
    ('Huesca', 'Huesca'),
    ('Jaén', 'Jaén'),
    ('La Rioja', 'La Rioja'),
    ('Las Palmas', 'Las Palmas'),
    ('León', 'León'),
    ('Lleida', 'Lleida'),
    ('Lugo', 'Lugo'),
    ('Madrid', 'Madrid'),
    ('Málaga', 'Málaga'),
    ('Murcia', 'Murcia'),
    ('Navarra', 'Navarra'),
    ('Ourense', 'Ourense'),
    ('Palencia', 'Palencia'),
    ('Pontevedra', 'Pontevedra'),
    ('Salamanca', 'Salamanca'),
    ('Santa Cruz de Tenerife', 'Santa Cruz de Tenerife'),
    ('Segovia', 'Segovia'),
    ('Sevilla', 'Sevilla'),
    ('Soria', 'Soria'),
    ('Tarragona', 'Tarragona'),
    ('Teruel', 'Teruel'),
    ('Toledo', 'Toledo'),
    ('Valencia', 'Valencia'),
    ('Valladolid', 'Valladolid'),
    ('Vizcaya', 'Vizcaya'),
    ('Zamora', 'Zamora'),
    ('Zaragoza', 'Zaragoza'),
]

class ImpuestoForm(forms.ModelForm):
    provincia = forms.ChoiceField(choices=PROVINCIAS)

    class Meta:
        model = ImpuestoSociedades
        fields = ['nif_cliente', 'cif_empresa', 'numero_impuesto', 'provincia', 'valor_producto', 'antiguedad_mayor_3']
