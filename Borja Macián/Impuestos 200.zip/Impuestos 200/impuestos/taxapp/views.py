from django.shortcuts import render, redirect
from .forms import ImpuestoForm
from .models import ImpuestoSociedades  # Modelo asociado al formulario

def formulario_impuesto(request):
    """Vista para manejar el formulario de impuestos"""
    if request.method == 'POST':
        form = ImpuestoForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request, 'taxapp/exito.html')  # Página de éxito
        else:
            return render(request, 'taxapp/error.html', {'form': form})  # Página de error
    else:
        form = ImpuestoForm()
    
    return render(request, 'taxapp/formulario.html', {'form': form})