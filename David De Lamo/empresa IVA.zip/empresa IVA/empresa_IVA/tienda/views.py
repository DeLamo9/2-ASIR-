import os
from django.shortcuts import render, redirect, get_object_or_404
from django.conf import settings
from django.utils import timezone
from django.contrib import messages
import xml.etree.ElementTree as ET
from xml.dom import minidom
from django.db import connection

from .models import Producto, Venta


from django.shortcuts import render, get_object_or_404
from .models import Producto
from django.contrib import messages

def lista_productos(request):
    productos = Producto.objects.all()  # Trae todos los productos de la BD
    for producto in productos:
        producto.total = producto.precio_con_iva()
    return render(request, 'tienda/lista_productos.html', {'productos': productos})



def comprar_producto(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)
    
    if request.method == 'POST':
        cantidad = int(request.POST.get('cantidad', 1))
        
        # Crear la venta histórica
        venta = Venta.objects.create(
            producto=producto,
            cantidad=cantidad
        )
        venta.save()
        
        # Insertar en la tabla diaria
        with connection.cursor() as cursor:
            cursor.execute("""
                INSERT INTO ventas_diarias (venta_id, producto_id, cantidad)
                VALUES (%s, %s, %s)
            """, [venta.id, producto.id, cantidad])
        
        root = ET.Element("Modelo303")
        ET.SubElement(root, "Fecha").text = timezone.now().strftime("%Y-%m-%d %H:%M:%S")
        ET.SubElement(root, "Producto").text = producto.nombre
        ET.SubElement(root, "Cantidad").text = str(cantidad)
        ET.SubElement(root, "BaseImponible").text = str(producto.precio_sin_iva)
        ET.SubElement(root, "IVARepercutido").text = f"{producto.calcular_iva():.2f}"
        ET.SubElement(root, "TotalFactura").text = str(producto.precio_con_iva())
        

        xml_str = ET.tostring(root, encoding='utf-8')
        parsed = minidom.parseString(xml_str)
        pretty_xml = parsed.toprettyxml(indent="  ")

        export_dir = os.path.join(settings.BASE_DIR, "exports")
        os.makedirs(export_dir, exist_ok=True)
        xml_filename = os.path.join(export_dir, f"venta_{venta.id}.xml")
        ET.ElementTree(root).write(xml_filename, encoding="utf-8", xml_declaration=True)
        

        with open(xml_filename, "w", encoding='utf-8') as f:
          f.write(pretty_xml)

        # Mensaje de confirmación
        messages.success(request, f'Has comprado {cantidad} x {producto.nombre}. Total: {venta.total_con_iva()} €')
        return render(request, 'tienda/gracias.html', {
    'producto': producto,
    'cantidad': cantidad,
    'total': venta.total_con_iva()
})


    return render(request, 'tienda/comprar.html', {
        'producto': producto,
        'precio_sin_iva': producto.precio_sin_iva,
        'iva': producto.calcular_iva(),
        'total': producto.precio_con_iva()
    })


