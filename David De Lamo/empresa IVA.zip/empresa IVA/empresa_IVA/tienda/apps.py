from django.apps import AppConfig
from django.db import connection

class TiendaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tienda'

    def ready(self):
        # Esto se ejecuta al iniciar Django
        with connection.cursor() as cursor:
            cursor.execute("TRUNCATE ventas_diarias RESTART IDENTITY;")
