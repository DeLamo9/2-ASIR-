from django.db import models
from decimal import Decimal, ROUND_HALF_UP

class Producto(models.Model):
    nombre = models.CharField(max_length=100)
    precio_sin_iva = models.DecimalField(max_digits=10, decimal_places=2)
    iva = models.DecimalField(max_digits=4, decimal_places=2, default=21.00)  # 21% por defecto
    imagen = models.ImageField(upload_to='productos/', blank=True, null=True, default='productos/default.jpg')

    def calcular_iva(self):
        """Devuelve el precio del IVA en euros"""
        return self.precio_sin_iva * (self.iva / 100)

    def precio_con_iva(self):
        """Devuelve el precio total (sin IVA + IVA)"""
        total = self.precio_sin_iva + self.calcular_iva()
        return total.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

    def __str__(self):
        return self.nombre

class Venta(models.Model):
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)
    fecha = models.DateTimeField(auto_now_add=True)

    def total_con_iva(self):
        return self.cantidad * self.producto.precio_con_iva()

    def __str__(self):
        return f"Venta de {self.cantidad} x {self.producto.nombre}"
