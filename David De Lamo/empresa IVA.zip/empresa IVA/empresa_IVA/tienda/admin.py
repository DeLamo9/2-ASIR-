from django.contrib import admin
from .models import Producto, Venta  # importa tus modelos

# Registra los modelos para que aparezcan en el panel de administración
admin.site.register(Producto)
admin.site.register(Venta)
