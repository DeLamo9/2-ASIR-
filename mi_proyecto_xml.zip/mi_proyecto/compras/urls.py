# compras/urls.py
from django.urls import path
from . import views  # aquí sí existe views.py en la app compras

urlpatterns = [
    path('', views.lista_productos, name='lista_productos'),
    path('crear/', views.crear_producto, name='crear_producto'),
    path('productos-xml/', views.ProductosXMLView.as_view(), name='productos_xml'),
]
