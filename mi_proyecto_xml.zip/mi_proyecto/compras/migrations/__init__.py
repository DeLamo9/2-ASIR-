from django.db import migrations, models
from decimal import Decimal

class Migration(migrations.Migration):
    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name='Producto',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('nombre', models.CharField(max_length=100)),
                ('precio_venta', models.DecimalField(max_digits=10, decimal_places=2)),
                ('tipo_iva', models.DecimalField(max_digits=4, decimal_places=2, default=Decimal('0.21'))),
                ('es_ingreso', models.BooleanField(default=False)),
                ('impuesto_electricidad', models.BooleanField(default=False)),
                ('impuesto_valor', models.DecimalField(max_digits=10, decimal_places=2, default=0)),
            ],
        ),
        migrations.RunSQL("""
            CREATE TABLE envios_aeat (
                id SERIAL PRIMARY KEY,
                producto_id INTEGER,
                impuesto NUMERIC(10,2),
                enviado BOOLEAN DEFAULT FALSE,
                fecha TIMESTAMP DEFAULT now()
            );

            CREATE OR REPLACE FUNCTION trigger_enviar_aeat()
            RETURNS TRIGGER AS $$
            BEGIN
                IF NEW.impuesto_valor IS DISTINCT FROM OLD.impuesto_valor THEN
                    INSERT INTO envios_aeat(producto_id, impuesto)
                    VALUES (NEW.id, NEW.impuesto_valor);
                END IF;
                RETURN NEW;
            END;
            $$ LANGUAGE plpgsql;

            CREATE TRIGGER trigger_enviar_aeat_update
            AFTER UPDATE ON compras_producto
            FOR EACH ROW
            EXECUTE FUNCTION trigger_enviar_aeat();
        """)
    ]
