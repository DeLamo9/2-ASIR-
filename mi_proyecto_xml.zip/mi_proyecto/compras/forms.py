from django import forms
from .models import ImpuestoElectricidad

class ImpuestoElectricidadForm(forms.ModelForm):
    class Meta:
        model = ImpuestoElectricidad
        fields = ['nombre', 'precio_venta', 'tipo_iva', 'impuesto_electricidad']
        labels = {
            'nombre': 'Nombre del gasto',
            'precio_venta': 'Importe',
            'tipo_iva': 'IVA (%)',
            'impuesto_electricidad': 'Impuesto de electricidad'
        }
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'precio_venta': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
            'tipo_iva': forms.Select(
                choices=[(0, 'Exento'), (0.05, '5%'), (0.10, '10%'), (0.21, '21%')],
                attrs={'class': 'form-control'}
            ),
            'impuesto_electricidad': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }
