from django.db import models
from decimal import Decimal

class ImpuestoElectricidad(models.Model):
    nombre = models.CharField(max_length=100)
    precio_venta = models.DecimalField(max_digits=10, decimal_places=2)
    tipo_iva = models.DecimalField(max_digits=4, decimal_places=2, default=Decimal('0.21'))
    es_ingreso = models.BooleanField(default=False)
    impuesto_electricidad = models.BooleanField(default=False)
    impuesto_valor = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    datos = models.TextField(blank=True, null=True)  # ← aquí agregas la columna para XML

    fecha_creacion = models.DateTimeField(auto_now_add=True)

    @property
    def calcular_iva(self):
        return (self.precio_venta * self.tipo_iva).quantize(Decimal('0.01'))

    @property
    def calcular_iee(self):
        if self.impuesto_electricidad:
            return (self.precio_venta * Decimal('0.0511269632')).quantize(Decimal('0.01'))
        return Decimal('0.00')

    @property
    def impuesto(self):
        return self.calcular_iva + self.calcular_iee

    @property
    def precio_total(self):
        return (self.precio_venta + self.impuesto).quantize(Decimal('0.01'))

    def save(self, *args, **kwargs):
        self.impuesto_valor = self.impuesto
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.nombre} ({self.precio_total} €)"

