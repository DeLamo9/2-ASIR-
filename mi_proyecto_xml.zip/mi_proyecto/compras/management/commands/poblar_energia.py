from django.core.management.base import BaseCommand
from compras.models import Producto
from decimal import Decimal

class Command(BaseCommand):
    help = "Pobla la base de datos con productos y servicios relacionados con energía"

    def handle(self, *args, **kwargs):
        # Limpiar primero
        Producto.objects.all().delete()

        productos = [
            {"nombre": "Factura electricidad hogar", "precio_venta": Decimal("120.50"), "tipo_iva": Decimal("0.21"), "es_ingreso": False, "impuesto_electricidad": True},
            {"nombre": "Factura gas natural", "precio_venta": Decimal("75.30"), "tipo_iva": Decimal("0.10"), "es_ingreso": False, "impuesto_electricidad": False},
            {"nombre": "Recibo agua caliente solar", "precio_venta": Decimal("50.00"), "tipo_iva": Decimal("0.05"), "es_ingreso": False, "impuesto_electricidad": False},
            {"nombre": "Venta panel solar usado", "precio_venta": Decimal("300.00"), "tipo_iva": Decimal("0.21"), "es_ingreso": True, "impuesto_electricidad": True},
            {"nombre": "Instalación sistema fotovoltaico", "precio_venta": Decimal("1500.00"), "tipo_iva": Decimal("0.21"), "es_ingreso": True, "impuesto_electricidad": True},
            {"nombre": "Mantenimiento caldera eléctrica", "precio_venta": Decimal("200.00"), "tipo_iva": Decimal("0.21"), "es_ingreso": False, "impuesto_electricidad": True},
            {"nombre": "Instalación termos eléctricos", "precio_venta": Decimal("350.00"), "tipo_iva": Decimal("0.21"), "es_ingreso": True, "impuesto_electricidad": True},
            {"nombre": "Batería doméstica para energía solar", "precio_venta": Decimal("800.00"), "tipo_iva": Decimal("0.21"), "es_ingreso": True, "impuesto_electricidad": True},
            {"nombre": "Factura electricidad industrial", "precio_venta": Decimal("450.75"), "tipo_iva": Decimal("0.21"), "es_ingreso": False, "impuesto_electricidad": True},
            {"nombre": "Recibo gas industrial", "precio_venta": Decimal("300.00"), "tipo_iva": Decimal("0.10"), "es_ingreso": False, "impuesto_electricidad": False},
            {"nombre": "Servicio de eficiencia energética", "precio_venta": Decimal("600.00"), "tipo_iva": Decimal("0.21"), "es_ingreso": True, "impuesto_electricidad": True},
            {"nombre": "Venta aerotermia doméstica", "precio_venta": Decimal("1200.00"), "tipo_iva": Decimal("0.21"), "es_ingreso": True, "impuesto_electricidad": True},
            {"nombre": "Reparación panel solar", "precio_venta": Decimal("180.00"), "tipo_iva": Decimal("0.21"), "es_ingreso": False, "impuesto_electricidad": True},
            {"nombre": "Factura agua caliente gas", "precio_venta": Decimal("65.00"), "tipo_iva": Decimal("0.10"), "es_ingreso": False, "impuesto_electricidad": False},
            {"nombre": "Auditoría energética hogar", "precio_venta": Decimal("90.00"), "tipo_iva": Decimal("0.21"), "es_ingreso": True, "impuesto_electricidad": False},
        ]

        for p in productos:
            Producto.objects.create(**p)

        self.stdout.write(self.style.SUCCESS("15 productos de energía creados correctamente."))
