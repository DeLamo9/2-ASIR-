from django.shortcuts import render, redirect
from django.views import View
from django.http import HttpResponse
from .models import ImpuestoElectricidad
from .forms import ImpuestoElectricidadForm
import xml.etree.ElementTree as ET
from decimal import Decimal

# -------------------------
# Vistas HTML / CRUD básico
# -------------------------

def lista_productos(request):
    productos = ImpuestoElectricidad.objects.all()
    return render(request, 'compras/lista_productos.html', {'productos': productos})

def crear_producto(request):
    if request.method == 'POST':
        form = ImpuestoElectricidadForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_productos')
    else:
        form = ImpuestoElectricidadForm()
    return render(request, 'compras/producto_form.html', {'form': form})

# -------------------------
# Vista para generar XML
# -------------------------

class ProductosXMLView(View):
    def get(self, request):
        productos = ImpuestoElectricidad.objects.all()

        root = ET.Element('productos')
        for p in productos:
            producto_elem = ET.SubElement(root, 'producto')
            ET.SubElement(producto_elem, 'nombre').text = p.nombre
            ET.SubElement(producto_elem, 'precio_venta').text = str(p.precio_venta)
            ET.SubElement(producto_elem, 'tipo_iva').text = str(p.tipo_iva)
            ET.SubElement(producto_elem, 'impuesto_valor').text = str(p.impuesto_valor)
            ET.SubElement(producto_elem, 'precio_total').text = str(p.precio_total)
            ET.SubElement(producto_elem, 'es_ingreso').text = str(p.es_ingreso)
            ET.SubElement(producto_elem, 'impuesto_electricidad').text = str(p.impuesto_electricidad)
            ET.SubElement(producto_elem, 'fecha_creacion').text = p.fecha_creacion.isoformat()

        xml_str = ET.tostring(root, encoding='utf-8', method='xml')
        return HttpResponse(xml_str, content_type='application/xml')

