import os
import sys
import django
import xml.etree.ElementTree as ET
from decimal import Decimal
sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/..")

# Configuración de Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mi_proyecto.settings')
django.setup()

from compras.models import ImpuestoElectricidad

def generar_xml():
    productos = ImpuestoElectricidad.objects.all()

    # Crear el nodo raíz
    root = ET.Element('productos')

    for p in productos:
        producto_el = ET.SubElement(root, 'producto')
        ET.SubElement(producto_el, 'nombre').text = p.nombre
        ET.SubElement(producto_el, 'precio_venta').text = str(p.precio_venta)
        ET.SubElement(producto_el, 'tipo_iva').text = str(p.tipo_iva)
        ET.SubElement(producto_el, 'impuesto_valor').text = str(p.impuesto_valor)
        ET.SubElement(producto_el, 'precio_total').text = str(p.precio_total)
        ET.SubElement(producto_el, 'es_ingreso').text = str(p.es_ingreso)
        ET.SubElement(producto_el, 'impuesto_electricidad').text = str(p.impuesto_electricidad)
        ET.SubElement(producto_el, 'fecha_creacion').text = p.fecha_creacion.isoformat()

    # Crear el árbol XML
    tree = ET.ElementTree(root)

    # Guardar XML a archivo
    with open('productos.xml', 'wb') as f:
        tree.write(f, encoding='utf-8', xml_declaration=True)

    print("XML generado correctamente: productos.xml")

if __name__ == '__main__':
    generar_xml()
