from django.shortcuts import render
from .models import Producto

def mostrar_producto(request):
    producto = Producto.objects.first()  # Solo tenemos uno
    return render(request, 'producto/detalle.html', {'producto': producto})
