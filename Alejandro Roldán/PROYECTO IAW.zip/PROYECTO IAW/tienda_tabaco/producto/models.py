from django.db import models

class Producto(models.Model):
    nombre = models.CharField(max_length=100)
    precio_base = models.DecimalField(max_digits=6, decimal_places=2)
    impuesto_especifico = models.DecimalField(max_digits=5, decimal_places=2, default=0.67)
    impuesto_ad_valorem = models.DecimalField(max_digits=5, decimal_places=2, default=48.50)  # Renombrado
    iva = models.DecimalField(max_digits=4, decimal_places=2, default=21.00)

    def impuesto_modelo_566(self):
        """
        Devuelve el importe añadido por el modelo 566
        """
        return (self.precio_base + self.impuesto_especifico) * (self.impuesto_ad_valorem / 100)

    def precio_sin_iva(self):
        """
        Precio base + impuesto modelo 566, sin IVA
        """
        return self.precio_base + self.impuesto_especifico + self.impuesto_modelo_566()
     
    def precio_final(self):
        """
        Precio base + impuesto modelo 566 + IVA
        """
        return self.precio_sin_iva() * (1 + self.iva / 100)

    def impuesto_iva(self):
        """
        Importe añadido por el IVA
        """
        return self.precio_final() - self.precio_sin_iva()
    
    def __str__(self):
        return self.nombre

