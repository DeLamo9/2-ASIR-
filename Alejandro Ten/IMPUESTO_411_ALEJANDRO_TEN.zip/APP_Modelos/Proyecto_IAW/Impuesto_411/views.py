# Impuesto_411/views.py
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from decimal import Decimal, InvalidOperation
import json
from .models import Formulario411

def formulario_411(request):
  if request.method == "GET":
    return render(request, "Impuesto_411/411.html")
  return JsonResponse({"ok": False, "error": "Use /api/impuesto411/ para POST"}, status=405)

@csrf_exempt
def impuesto_411_api(request):
  if request.method != "POST":
    return JsonResponse({"ok": False, "error": "Method not allowed"}, status=405)

  ctype = (request.META.get("CONTENT_TYPE") or "").lower()
  if "application/json" in ctype:
    try:
      payload = json.loads(request.body.decode("utf-8") or "{}")
    except json.JSONDecodeError:
      return JsonResponse({"ok": False, "error": "JSON inválido"}, status=400)
  else:
    payload = request.POST.dict()

  def to_decimal(v):
    if v in (None, ""): return Decimal("0")
    return Decimal(str(v).replace(",", "."))

  try:
    anio_entrada = payload.get("año") or payload.get("anio")  # tu modelo tiene "año"
    # No conviertas a int si el campo del modelo es CharField
    obj = Formulario411.objects.create(
      nif=payload.get("nif"),
      iban=payload.get("iban"),
      cif=payload.get("cif"),
      año=anio_entrada,
      base_imponible=to_decimal(payload.get("base_imponible")),
      territorio=payload.get("territorio") or "No presencial",
      # Solo si existen en el modelo:
      # cuota_tributaria=to_decimal(payload.get("cuota_tributaria")),
      # importe_ingresar=to_decimal(payload.get("importe_ingresar")),
    )
    return JsonResponse({"ok": True, "id": obj.id}, status=201)

  except InvalidOperation:
    return JsonResponse({"ok": False, "error": "Formato numérico inválido"}, status=400)
  except Exception as e:
    # log para depurar en consola
    print("ERROR guardando Formulario411:", e)
    print("Payload recibido:", payload)
    return JsonResponse({"ok": False, "error": str(e)}, status=500)
