from django.db import migrations

CREATE_TRIGGER_SQL = r"""
DO $$
BEGIN
  -- Solo si la tabla existe y el trigger aún no está creado
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'public'
      AND table_name = 'impuesto_411_formulario411'
  ) THEN
    IF NOT EXISTS (
      SELECT 1 FROM pg_trigger WHERE tgname = 'trg_formulario411_after_insert'
    ) THEN
      EXECUTE 'CREATE TRIGGER trg_formulario411_after_insert
               AFTER INSERT ON impuesto_411_formulario411
               FOR EACH ROW
               EXECUTE FUNCTION imp411.fn_capture_formulario411()';
    END IF;
  END IF;
END$$;
"""

DROP_TRIGGER_SQL = r"""
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'public'
      AND table_name = 'impuesto_411_formulario411'
  ) THEN
    IF EXISTS (
      SELECT 1 FROM pg_trigger WHERE tgname = 'trg_formulario411_after_insert'
    ) THEN
      EXECUTE 'DROP TRIGGER trg_formulario411_after_insert ON impuesto_411_formulario411';
    END IF;
  END IF;
END$$;
"""

class Migration(migrations.Migration):

    dependencies = [
        ('Impuesto_411', '0002_rename_ejercicio_formulario411_anio_and_more'),
        # Si no tuvieras 0002, usa: ('Impuesto_411', '0001_initial')
    ]

    operations = [
        migrations.RunSQL(
            sql=CREATE_TRIGGER_SQL,
            reverse_sql=DROP_TRIGGER_SQL,
        ),
    ]
