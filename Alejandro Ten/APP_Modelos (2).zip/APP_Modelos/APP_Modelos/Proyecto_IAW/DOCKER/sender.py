import os, time, json, sys
import psycopg2
import requests

ENDPOINT = os.getenv("IMP411_ENDPOINT", "http://172.20.10.12:8000/api/impuestos")

def get_conn():
    return psycopg2.connect(
        host=os.getenv("POSTGRES_HOST", "db"),
        port=int(os.getenv("POSTGRES_PORT", "5432")),
        dbname=os.getenv("POSTGRES_DB", "postgres"),
        user=os.getenv("POSTGRES_USER", "postgres"),
        password=os.getenv("POSTGRES_PASSWORD", "postgres")
    )

SQL_GROUPS = """
WITH pend AS (
  SELECT id, cif_empresa, nif_cliente, numero_impuesto, datos, created_at
  FROM imp411.impuesto_outbox_raw
  WHERE sent = FALSE
)
SELECT
  cif_empresa,
  nif_cliente,
  numero_impuesto,
  jsonb_agg(datos ORDER BY created_at) AS datos,
  array_agg(id ORDER BY created_at)   AS ids
FROM pend
GROUP BY 1,2,3;
"""

SQL_MARK_SENT = """
UPDATE imp411.impuesto_outbox_raw
SET sent = TRUE, sent_at = now()
WHERE id = ANY(%s::bigint[]);
"""

def tick_once():
    with get_conn() as conn:
        conn.autocommit = False
        with conn.cursor() as cur:
            cur.execute(SQL_GROUPS)
            groups = cur.fetchall()

        for (cif, nif, num, datos, ids) in groups:
            payload = {
                "cif_empresa": cif,
                "nif_cliente": nif,
                "numero_impuesto": int(num),
                "datos": datos,  # <- lista de objetos
            }
            try:
                res = requests.post(ENDPOINT, json=payload, timeout=10)
                ok = (200 <= res.status_code < 300)
            except Exception as e:
                ok = False

            if ok:
                with conn.cursor() as cur:
                    cur.execute(SQL_MARK_SENT, (ids,))
                conn.commit()
            else:
                conn.rollback()  # mantenemos pendientes para reintentar

if __name__ == "__main__":
    interval = int(os.getenv("IMP411_INTERVAL_SEC", "30"))
    while True:
        try:
            tick_once()
        except Exception as e:
            # no paramos el bucle: log y seguimos
            print(f"[sender] error: {e}", file=sys.stderr)
        time.sleep(interval)
