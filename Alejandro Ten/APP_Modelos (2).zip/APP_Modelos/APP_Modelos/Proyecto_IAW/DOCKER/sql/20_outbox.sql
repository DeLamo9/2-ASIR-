-- 20_outbox.sql — SOLO esquema + tabla + función (sin trigger)
CREATE SCHEMA IF NOT EXISTS imp411;

CREATE TABLE IF NOT EXISTS imp411.impuesto_outbox_raw (
  id              BIGSERIAL PRIMARY KEY,
  cif_empresa     TEXT NOT NULL,
  nif_cliente     TEXT NOT NULL,
  numero_impuesto INT  NOT NULL,
  datos           JSONB NOT NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  sent            BOOLEAN NOT NULL DEFAULT FALSE,
  sent_at         TIMESTAMPTZ
);

-- Función que usará el trigger (la función puede existir ya)
CREATE OR REPLACE FUNCTION imp411.fn_capture_formulario411()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO imp411.impuesto_outbox_raw(cif_empresa, nif_cliente, numero_impuesto, datos)
  VALUES (
    NEW.cif,
    NEW.nif,
    411,
    jsonb_build_object(
      'anio', NEW."año",
      'iban', NEW.iban,
      'base_imponible', NEW.base_imponible,
      'cuota_tributaria', NEW.cuota_tributaria,
      'importe_ingresar', NEW.importe_ingresar,
      'territorio', NEW.territorio,
      'fecha_creacion', NEW.fecha_creacion
    )
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
