from django.contrib import admin
from django.urls import path, include
from apuestas.views import apuestas_view
urlpatterns = [
    path('admin/', admin.site.urls),
    path('apuestas/', include('apuestas.urls')),  # Ruta de la app Apuestas
]
