from django.shortcuts import render, get_object_or_404
from .models import apuestas  # Tu modelo

def apuestas_view(request):
    producto = apuestas.objects.all()
    return render(request, "apuestas.html", {"producto": producto})
    # Obtenemos el único objeto (pk=1)
    apuesta_obj = get_object_or_404(apuestas, pk=1)


    # Calculamos el impuesto (por ejemplo, 21%)
    impuesto = apuesta_obj.precio * 0.21
    total = apuesta_obj.precio + impuesto

    context = {
        "apuesta": apuesta_obj,
        "impuesto": impuesto,
        "total": total
    }
    return render(request, "apuestas/apuestas.html", context)
