from django.contrib import admin
from .models import apuestas  # Cambia 'Producto' por el nombre real de tu modelo

admin.site.register(apuestas)

class ApuestaAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'precio', 'disponible')