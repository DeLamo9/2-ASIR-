from django.db import models

class apuestas(models.Model):
    TIPO_CHOICES = [
        ("venta", "Venta"),
        ("ingreso", "Ingreso no venta (pensión, renta, etc.)"),
    ]

    nombre = models.CharField(max_length=200)
    tipo = models.CharField(max_length=20, choices=TIPO_CHOICES, default="venta")
    precio_publico = models.DecimalField(max_digits=10, decimal_places=2)
    tasa_impuesto = models.DecimalField(max_digits=4, decimal_places=2, default=0.21)

    def calcular_impuesto(self):
        return self.precio_publico * self.tasa_impuesto

    def precio_total(self):
        return self.precio_publico + self.calcular_impuesto()

    def __str__(self):
        return f"{self.nombre} ({self.get_tipo_display()})"

class Producto(models.Model):
    nombre = models.CharField(max_length=100)
    precio = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.nombre
